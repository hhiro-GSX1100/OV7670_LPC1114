#ifdef TARGET_LPC1114
#include "MODSERIAL.h"

void MODSERIAL::setBase(void ) {
    _base = LPC_UART;
    _IRQ = UART_IRQn;
}

void MODSERIAL::initDevice(void) {
    ((LPC_UART_TypeDef*)_base)->FCR = (1UL<<0) + (1UL<<1) + (1UL<<2);
    }

bool MODSERIAL::txIsBusy( void ) 
{ 
    return ( (((LPC_UART_TypeDef*)_base)->LSR & ( 1UL << 6 )) == 0 ) ? true : false; 
} 
#endif