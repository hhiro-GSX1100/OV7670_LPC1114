#pragma once 
#include "mbed.h"
#include "ov7670.h"
#include "MODSERIAL.h"

//GPIO0 
//bit 11 10  9  8  7  6  5  4  3  2  1  0
//pin  4  3  2  1 28  6  5 27 26 25 24 23
//MASK 1  0  1  1  1  1  0  0  1  1  1  0
//=
//DATA     7  6  5  4  3  2  1  0
//LPC_PIN  4  2  1 28  6 26 25 24

//GPIO１ 
//bit 11 10  9  8  7  6  5  4  3  2  1  0
//pin  4  3 18 17 16 15 14 13 12 11 10  9
#define BAUD      460800  
//#define BAUD      115200 
#define USBTX     dp16
#define USBRX     dp15
#define I2C_SDA   dp5
#define I2C_SCL   dp27
#define DATA_PORT Port0
#define DATA_PORT_MASK 0xbce //0b101111001110 dp23,25,26,27,28
#define CAM_VSYNC dp9
#define CAM_WEN   dp10  //WR
#define CAM_RRST  dp11  //RRST
#define CAM_OE    dp17  //OE
#define CAM_RCLK  dp18  //RCK
//VSYNC    21 VSYNC FIFO_WRST-FIFO write pointer reset terminal
//PullUp   15 RST   RESTE --- reset port (normally pulled high)
//PullDown 16 PWDN  PWDN ---- Power Select mode (normal low)
//NC       17 STR   STROBE-camera flash control port (normal use may not be required)
//D0 dp24
//D1 dp25
//D2 dp26
//D3 dp6
//D4 dp28
//D5 dp1
//D6 dp2
//D7 dp4
#define LED_PIN dp14
MODSERIAL pc(USBTX,USBRX);
Timer t;
bool new_send = false;

DigitalOut led1(LED_PIN);


//Camera
OV7670 camera
(
    I2C_SDA,I2C_SCL,              // SDA,SCL(I2C / SCCB)
    CAM_VSYNC,NC,CAM_WEN,         // VSYNC,HREF,WEN(FIFO)  
    DATA_PORT,DATA_PORT_MASK,     // PortIn data        p18(P0.26),p17(P0.25),p16(P0.24),p15(P0.23),p11(P0.18),p12(P0.17),p14(P0.16),p13(P0.15)
    CAM_RRST,CAM_OE,CAM_RCLK      // RRST,OE,RCLK
); 

//RESET
extern "C" void mbed_reset(){
    NVIC_SystemReset();
};

//Serial
char word[25];
int t1 = 0; 
int t2 = 0;
int t3 = 0;

//
void parse_cmd();
void CameraSnap();
void CameraGrab();
